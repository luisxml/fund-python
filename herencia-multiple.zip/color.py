class Color:
    def __init__(self, color):
        self.color = color
        
        